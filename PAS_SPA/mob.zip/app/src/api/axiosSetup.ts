import axios from 'axios';

const axiosSetup = axios.create({
    baseURL: 'http://192.168.18.119:8080/PAS_PD-1/api/v1',
    headers: {
        'Content-Type': 'application/json',
    },
});

export default axiosSetup;