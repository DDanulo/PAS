import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import Toast from 'react-native-toast-message'; // Native replacement for toastify

// You will need to convert these pages next.
// If they don't exist yet, comment them out or make dummy components.
import UserList from '../src/pages/UserList';
import UserForm from '../src/pages/UserForm';
import UserDetails from '../src/pages/UserDetails';
import ReservationList from '../src/pages/ReservationList';
import ReservationForm from '../src/pages/ReservationForm';

const Stack = createNativeStackNavigator();

export default function App() {
    return (
        <NavigationContainer>
            {/* "initialRouteName" acts like your <Navigate to="/users" /> */}
            <Stack.Navigator initialRouteName="UserList">

                {/* Route: /users */}
                <Stack.Screen
                    name="UserList"
                    component={UserList}
                    options={{ title: 'Klienci' }}
                />

                {/* Route: /users/new */}
                <Stack.Screen
                    name="UserNew"
                    component={UserForm}
                    options={{ title: 'Dodaj Klienta' }}
                />

                {/* Route: /users/edit/:id */}
                {/* In Native, we reuse the same component. We pass 'id' via params later. */}
                <Stack.Screen
                    name="UserEdit"
                    component={UserForm}
                    options={{ title: 'Edytuj Klienta' }}
                />

                {/* Route: /users/:id */}
                <Stack.Screen
                    name="UserDetails"
                    component={UserDetails}
                    options={{ title: 'Szczegóły Klienta' }}
                />

                {/*Route: /reservations */}
                <Stack.Screen
                    name="ReservationList"
                    component={ReservationList}
                    options={{ title: 'Rezerwacje' }}
                />

                {/* Route: /reservations/new */}
                <Stack.Screen
                    name="ReservationNew"
                    component={ReservationForm}
                    options={{ title: 'Nowa Rezerwacja' }}
                />

            </Stack.Navigator>

            {/* The Toast component sits outside the navigation */}
            <Toast />
        </NavigationContainer>
    );
}